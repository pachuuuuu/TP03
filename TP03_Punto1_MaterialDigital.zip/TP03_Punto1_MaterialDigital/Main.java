public class Main {
    public static void main(String[] args) {
        // Crear un LibroDigital y un Audiolibro
        LibroDigital libro = new LibroDigital("Cien años de soledad");
        Audiolibro audiolibro = new Audiolibro("El Aleph");

        // Ejecutar mostrarDescripcion() en ambos
        System.out.println("--- Biblioteca Digital ---");
        libro.mostrarDescripcion();
        audiolibro.mostrarDescripcion();
    }
}
