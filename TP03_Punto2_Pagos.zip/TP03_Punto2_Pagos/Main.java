public class Main {
    public static void main(String[] args) {
        // Crear un objeto de cada subclase
        Tarjeta tarjeta = new Tarjeta("Juan Pérez", "4589");
        BilleteraVirtual billetera = new BilleteraVirtual("Sofía López", "Mercado Pago");

        System.out.println("--- Procesamiento de Pagos ---");
        // Procesar un pago de prueba válido con cada uno
        tarjeta.procesarPago(15000.0);
        billetera.procesarPago(4250.50);

        System.out.println("\n--- Prueba de Validación (Monto <= 0) ---");
        tarjeta.procesarPago(-100.0);
        billetera.procesarPago(0);
    }
}
